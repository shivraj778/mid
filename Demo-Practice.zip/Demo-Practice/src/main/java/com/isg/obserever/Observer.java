package com.isg.obserever;

public interface Observer {

	void printNewData();

	void update(int id, String name, String city);

}