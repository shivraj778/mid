package com.isg.obserever;


import com.isg.subject.College;
import com.isg.subject.Subject;

public class Staff implements Observer {
	private int id;
	private String name;
	private String city;
	private String staffName;
	
	private College subscribe;
	
    public Staff()
    {
		super();
	}

   public Staff(String staffName) {
	    super();
		this.staffName = staffName;
		System.out.println("in staff constsructor");
		System.out.println(this.staffName);
	}

    @Override
	public void update(int id, String name, String city)
	{
		this.id = id;
		this.name = name;
		this.city = city;
		printNewData();
	}
	
	@Override
	public void printNewData() 
	{
		System.out.println(staffName + ": Name: " + name + ", Id: " + id + ", city: " + city);
	}

	
}
