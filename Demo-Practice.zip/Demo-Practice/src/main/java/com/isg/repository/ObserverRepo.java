package com.isg.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.isg.model.CollegeModel;

@Repository
public interface ObserverRepo extends CrudRepository<CollegeModel, Integer> {
	
}
