package com.isg.subject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.model.CollegeModel;
import com.isg.obserever.Observer;
import com.isg.repository.ObserverRepo;



public class College implements Subject {
	
	 @Autowired
	private ObserverRepo repo;
    private List<Observer> observer = new ArrayList();
    
	public College() {
		super();
	}

	@Override
	public void register(Observer newStaff) {
		observer.add(newStaff);
		System.out.println("in register");
	}

	@Override
	public void unRegister(Observer deleteStaff) {
		observer.remove(deleteStaff);
	}

	@Override
	public void notifyStudents() {
		System.out.println("in notify");
		
		for (Observer staff : observer) {
			 CollegeModel model = new CollegeModel();
			staff.update(model.getId(), model.getName(), model.getCity());
			}
	}

	@Override
	public void upload() throws IOException 
	{
		  System.out.println("in upload");
          byte[] jsonData =Files.readAllBytes(Paths.get("src/","StudentData.txt"));
		  ObjectMapper objectMapper = new ObjectMapper(); 
		  CollegeModel obj1 = objectMapper.readValue(jsonData, CollegeModel.class);
		  CollegeModel obj2 = new CollegeModel();
		  
		  List<CollegeModel> data = obj2.setMethods(obj1); 
		
		  data = (List<CollegeModel>) repo.saveAll(data);
		  data.forEach((n) -> System.out.println(n));
		  	
			
	}

}
