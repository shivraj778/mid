package com.isg.subject;

import java.io.IOException;

import com.isg.obserever.Observer;

public interface Subject {

	void register(Observer staffName);

	void unRegister(Observer deleteStaff);

	void notifyStudents();

	void upload() throws IOException;

	

	

}