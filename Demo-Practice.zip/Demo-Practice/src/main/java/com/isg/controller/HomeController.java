package com.isg.controller;

import java.io.IOException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.obserever.Staff;
import com.isg.subject.College;
import com.isg.subject.Subject;

@RestController
public class HomeController {
	
	@PostMapping("/update")
	public void update() throws IOException {
		 System.out.println("in main");
		  
		  Subject sub= new College();
		  Staff staff1 = new Staff("Nilesh");
		  sub.register(staff1);
		  
		/*
		 * Staff staff2 = new Staff("Raman"); sub.register(staff2);
		 */
	      sub.upload();
		 sub.notifyStudents();
		  
		
	}

}
