
  package com.isg;
  
  import java.io.IOException;

import org.springframework.boot.SpringApplication; import
  org.springframework.boot.autoconfigure.SpringBootApplication;

import com.isg.obserever.Staff;
import com.isg.subject.College;
import com.isg.subject.Subject;
  
  @SpringBootApplication 
  public class DemoPracticeApplication {
  
  public static void main(String[] args) {
  SpringApplication.run(DemoPracticeApplication.class, args); 
  
 
  
  
  }
  
  }
 