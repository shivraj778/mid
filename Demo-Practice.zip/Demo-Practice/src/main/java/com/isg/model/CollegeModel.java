package com.isg.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Colle")
public class CollegeModel {
	@Id
	private int id;
	@Column
	private String name;
	@Column
	private String city;
	
	public CollegeModel(int id, String name, String city) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
	}

	public CollegeModel() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public List<CollegeModel> setMethods(CollegeModel obj2)
	{	
		List<CollegeModel> list =new ArrayList<>();
		CollegeModel clg = new CollegeModel();
		clg.setName(this.getName());
		clg.setId(this.getId());
		clg.setCity(this.getCity());
		
		list.add(clg);
		return list;
	}

}
