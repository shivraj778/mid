package com.isg.accesspoint.middleware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
