package com.isg.middleware.parser.isofield;

import org.jpos.iso.ISOStringFieldPackager;
import org.jpos.iso.NullPadder;
import org.jpos.iso.NullPrefixer;

import com.isg.middleware.parser.interpreter.HexToAsciiInterpreter;

public class IFH_ACHAR extends ISOStringFieldPackager {

	public IFH_ACHAR() {
		super(NullPadder.INSTANCE, HexToAsciiInterpreter.INSTANCE, NullPrefixer.INSTANCE);
	}

	/**
	 * @param len         - field len
	 * @param description symbolic descrption
	 */
	public IFH_ACHAR(int len, String description) {
		super(len, description, NullPadder.INSTANCE, HexToAsciiInterpreter.INSTANCE, NullPrefixer.INSTANCE);
		checkLength(len, 9999);
	}

	@Override
	public void setLength(int len) {
		checkLength(len, 9999);
		super.setLength(len);
	}
}
