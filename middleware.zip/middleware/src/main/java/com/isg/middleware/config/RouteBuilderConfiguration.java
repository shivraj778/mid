package com.isg.middleware.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.isg.middleware.routes.TransactionRequestTCPRoute;

@Configuration
public class RouteBuilderConfiguration {

	@Bean
	@Scope(value="prototype")
    public TransactionRequestTCPRoute routeBean() {
		return new TransactionRequestTCPRoute();
	}
}
