package com.isg.middleware.bean;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ISO8583 {
	private String txnId;
	private String rawMsg;
	private String length;
	private String tpdu;
	private String mti;
	private String bitmap;
	private DataElement[] dataElements;

	private LocalDateTime createdDate;
	private String createdBy;

}
