package com.isg.middleware.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DataElement {

	//@JsonAlias("DE01")
	private String de002;
	private String de003;
	private String de004;
	private String de011;
	private String de012;
	private String de013;
	private String de014;
	private String de022;
	private String de024;
	private String de025;
	private String de035;
	private String de037;
	private String de038;
	private String de039;
	private String de041;
	private String de042;
	private String de043;
	private String de045;
	private String de048;
	private String de052;
	private String de053;
	private String de054;
	private String de055;
	private String de060;
	private String de061;
	private String de062;
	private String de063;
}
