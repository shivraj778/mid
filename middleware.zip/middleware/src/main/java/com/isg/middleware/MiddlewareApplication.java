package com.isg.middleware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiddlewareApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiddlewareApplication.class, args);

//		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
//		ctx.register(RouteBuilderConfiguration.class);
//		ctx.refresh();
//
//		TransactionRequestTCPRoute mb1 = ctx.getBean(TransactionRequestTCPRoute.class);
//		System.out.println(mb1.hashCode());

//		TransactionRequestTCPRoute mb2 = ctx.getBean(TransactionRequestTCPRoute.class);
//		System.out.println(mb2.hashCode());
//		ctx.close();
	}

}
