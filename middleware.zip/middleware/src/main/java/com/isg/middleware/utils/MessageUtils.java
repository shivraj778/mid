package com.isg.middleware.utils;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Utility class to get the messages based on language and country set in the appconfig.properties.<br>
 * Default Locale is US English.<br>
 * Visit the following link to identify all the locale supported in Java 8.<br>
 * <link>https://www.oracle.com/technetwork/java/javase/java8locales-2095355.html</link>
 * 
 * @author juber3709
 *
 */
@Configuration
public class MessageUtils {
	
	@Value("${locale.language:en}")
	private String language;
	
	@Value("${locale.country:US}")
	private String country;
	
	private static ResourceBundle messagesBundle;
	
	public static String getMessage(String msgKey) {
		return (String) messagesBundle.getObject(msgKey);
	}
	
	@PostConstruct
	public void postConstruct() {
		Locale locale = new Locale(language, country);
		ResourceBundle messagesBundleTemp = ResourceBundle.getBundle("messages", locale);
		MessageUtils.messagesBundle = messagesBundleTemp;
	}

}
