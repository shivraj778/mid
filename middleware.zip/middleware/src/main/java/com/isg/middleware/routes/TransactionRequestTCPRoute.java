package com.isg.middleware.routes;


import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.middleware.bean.ISO8583;
import com.isg.middleware.parser.ISO8583Parser;
import com.isg.middleware.service.TransactionRequestRouteService;
import com.isg.middleware.utils.PropertyUtils;

public class TransactionRequestTCPRoute extends BaseRouteBuilder {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Value("${route.kafka.kp.txnlog.insert}")
	private String kpTxnLogInsert;
	
	@Value("${route.kafka.kp.txnlog.update}")
	private String kpTxnLogUpdate;

	@Value("${kafka.brokers}")
	private String kafkaBrokers;
	

	
	@Autowired
	private TransactionRequestRouteService routeService;
	
	@Override
	public void configure() throws Exception {
		
		super.configure();
		
		//If reuseChannel=true is used then the parsed msg get returned to the nc client
		from("netty:tcp://{{route.middleware.tcpserver.port}}?sync=true&textline=true&reuseChannel=true")
		.bean(TransactionRequestRouteService.class, "validateMsg")
		.wireTap("direct:txn-log")
		.to("direct:tcp-client");
		
		from("direct:txn-log")
		.bean(TransactionRequestRouteService.class, "setTxnId")
		.to("kafka:" + kpTxnLogInsert + "?brokers=" + kafkaBrokers)
		.process(exchange -> {
			String body = (String) exchange.getIn().getBody();
			
			ObjectMapper objectMapper = new ObjectMapper();
			ISO8583 iso8583Obj = null;
			try {
				iso8583Obj = objectMapper.readValue(body, ISO8583.class);
			} catch (IOException e) {
				logger.debug("{}{}",PropertyUtils.getProperty("MW-com.isg.middleware.routes-001"), e);
			}
			String parsedMsg = ISO8583Parser.parse(iso8583Obj.getRawMsg());
			ISO8583 toIso8583Obj = routeService.toISO8583Object(parsedMsg);
			toIso8583Obj.setTxnId(iso8583Obj.getTxnId());
			exchange.getIn().setBody(toIso8583Obj);
			logger.info("{}{}",PropertyUtils.getProperty("MW-com.isg.middleware.routes-002"), toIso8583Obj);
		})
		.marshal().json()
		.to("kafka:" + kpTxnLogUpdate + "?brokers=" + kafkaBrokers);
		
		from("direct:tcp-client")
		.process(exchange -> {
			String transactionMsg = (String) exchange.getIn().getBody();
			logger.info("{}{}",PropertyUtils.getProperty("MW-com.isg.middleware.routes-003"),transactionMsg);
			String parsedMsg = ISO8583Parser.parse(transactionMsg);
			logger.info("{}{}",PropertyUtils.getProperty("MW-com.isg.middleware.routes-004"),parsedMsg);
			exchange.getIn().setBody(parsedMsg);
		})
		
		.to("netty:tcp://{{route.middleware.tcpclient.port}}?sync=true&textline=true&clientMode=true")
		.process(exchange -> {
			logger.info("{}{}"+" ",PropertyUtils.getProperty("MW-com.isg.middleware.routes-005"),exchange.getIn().getHeaders());
			String transactionMsg = exchange.getIn().getBody(String.class);
			String parsedMsg = ISO8583Parser.parse(transactionMsg);
			exchange.getIn().setBody(parsedMsg);
		});
	}

}
