package com.isg.middleware.routes;

import org.apache.camel.builder.RouteBuilder;

public class BaseRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		
	}

}
