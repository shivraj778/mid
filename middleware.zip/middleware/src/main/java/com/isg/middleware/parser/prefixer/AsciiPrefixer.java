package com.isg.middleware.parser.prefixer;

import org.jpos.iso.ISOException;
import org.jpos.iso.Prefixer;

public class AsciiPrefixer implements Prefixer {

	public static final AsciiPrefixer LLLL = new AsciiPrefixer(4);

	public static final AsciiPrefixer LLL = new AsciiPrefixer(3);

	public static final AsciiPrefixer LL = new AsciiPrefixer(2);

	private int nDigits;

	public AsciiPrefixer(int nDigits) {
		this.nDigits = nDigits;
	}

	@Override
	public void encodeLength(int length, byte[] b) throws ISOException {
		throw new UnsupportedOperationException("encodeLength method not implemented");
	}

	@Override
	public int decodeLength(byte[] b, int offset) throws ISOException {
		int len = 0;
		for (int i = 0; i < nDigits; i++) {
			byte d = b[offset + i];
			if (d < '0' || d > '9') {
				throw new ISOException("Invalid character found. Expected digit.");
			}
			len = len * 10 + d - (byte) '0';
		}
		return len * 2;
	}

	@Override
	public int getPackedLength() {
		return nDigits;
	}

}
