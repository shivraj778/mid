package com.isg.middleware.service;

import java.io.IOException;
import java.time.LocalDateTime;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.isg.middleware.bean.ISO8583;
import com.isg.middleware.exception.ValidationException;
import com.isg.middleware.utils.PropertyUtils;
import com.isg.middleware.utils.Util;

@Service
public class TransactionRequestRouteService {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	public void validateMsg(Exchange exchange) {
		String msg = exchange.getIn().getBody(String.class);
		if (msg == null || msg.trim().isEmpty()) {
			// stopping the further route processing, since msg is null
			exchange.setException(new ValidationException(PropertyUtils.getProperty("MW-com.isg.middleware.service-008")));
			exchange.setProperty(Exchange.ROUTE_STOP, Boolean.TRUE);
		}
	}

	public void setTxnId(Exchange exchange) {
		String transactionMsg = (String) exchange.getIn().getBody();
		ObjectMapper mapper = new ObjectMapper();
		String txnId = getTransactionId();
		ObjectNode transaction = mapper.createObjectNode();
		transaction.put("txnId", txnId);
		transaction.put("rawMsg", transactionMsg);
		try {
			exchange.getIn().setBody(mapper.writeValueAsString(transaction));
		} catch (JsonProcessingException e) {
			exchange.setException(e);
			logger.debug("{}{}",PropertyUtils.getProperty("MW-com.isg.middleware.service-006"),e);
		}
	}

	public ISO8583 toISO8583Object(String body) {
		ObjectMapper objectMapper = new ObjectMapper();
		ISO8583 iso8583Obj = null;
		try {
			iso8583Obj = objectMapper.readValue(body, ISO8583.class);
		} catch (IOException e) {
			logger.debug("{}{}",PropertyUtils.getProperty("MW-com.isg.middleware.service-007"), e);
		}
		return iso8583Obj;
	}

	public String getTransactionId() {
		return Util.formatDate(LocalDateTime.now(), "yyyyMMddss");
	}

}
