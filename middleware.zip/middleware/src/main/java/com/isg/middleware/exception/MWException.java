package com.isg.middleware.exception;

public class MWException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public MWException(String message) {
		super(message);
	}

}