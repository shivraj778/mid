package com.isg.asynchronous;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsyncLoggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
