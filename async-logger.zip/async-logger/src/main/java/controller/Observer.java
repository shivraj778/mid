package controller;

public interface Observer {

	void update(String name, int id, String city);

	void printNewData();

}