package controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController("/home")
public class Controller {
	
	@Autowired
	private Collage clg;
	
	@PostMapping("/update")
	public void update() throws IOException
	{
	  clg.upload();
	}

}
