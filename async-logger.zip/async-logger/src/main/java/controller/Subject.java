package controller;

import java.io.IOException;

public interface Subject {

	void register(Staff newStudent);

	void unRegister(Observer deleteStudent);

	void notifyStudents();

	void upload() throws IOException;

}