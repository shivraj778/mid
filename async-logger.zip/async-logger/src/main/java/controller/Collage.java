package controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class Collage implements Subject {
    private List<Staff> students = new ArrayList();
	private String name;
	private int id;
	private String city;
	private int observerID;
	private static int observerIDTracker = 0;
	
	public void setName(String name)
	{
		this.name = name;
		
	}

	public void setId(int id)
	{
		this.id = id;
		
    }

	public void setCity(String city) 
	{
		this.city = city;
		notifyStudents();
	}

	@Override
	public void register(Staff newStudent) {
		students.add(newStudent);
	}

	@Override
	public void unRegister(Observer deleteStudent) {
		int observerIndex = students.indexOf(deleteStudent);
		System.out.println("observer " + (observerIndex+1) + "deleted");
		students.remove(observerIndex);
	}

	@Override
	public void notifyStudents() {
		Collage obj = new Collage();
		Staff observer1 = new Staff("mr. shaha");
		students.add(observer1);
		Staff observer2 = new Staff("mr. dev");
		students.add(observer2);
		Staff observer3 = new Staff("mr. prasad");
		students.add(observer3);
		
		for (Observer student : students) {
			this.observerID = ++observerIDTracker;
			System.out.println("observer " + observerID);
			student.update(name, id, city);
			}
	}

	@Override
	public void upload() throws IOException 
	{
          byte[] jsonData =Files.readAllBytes(Paths.get("src/","StudentData.txt"));
		  ObjectMapper objectMapper = new ObjectMapper(); 
		  Collage clg = objectMapper.readValue(jsonData,Collage.class); 
		  
    }

}
