package controller;

public class Staff implements Observer {
	private String name;
	private int id;
	private String city;
	private String staffName;
	
    
    private Collage collage;
    
    public Staff() {
		super();
	}

	
	
	public Staff(String name) {
		super();
		this.staffName = name;
	}



	@Override
	public void update(String name,int id, String city)
	{
		this.name = name;
		this.id = id;
		this.city = city;
		printNewData();
	}
	
	@Override
	public void printNewData() 
	{
		System.out.println(staffName + ": Name: " + name + ", Id: " + id + ", city: " + city);
	}

	
}
