package com.isg.asynchronous.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiddlewareApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(MiddlewareApplication.class, args);
		
		/*
		 * CamelContext camelContext=new DefaultCamelContext();
		 * camelContext.addRoutes(new TransactionRequestTCPRoute());
		 * camelContext.start(); Thread.sleep(3*60*1000); camelContext.stop();
		 */
		
		
	}

	/*
	 * @Bean ServletRegistrationBean servletRegistrationBean() {
	 * ServletRegistrationBean servlet = new ServletRegistrationBean(new
	 * CamelHttpTransportServlet(), "/camel/*"); servlet.setName("CamelServlet");
	 * return servlet; }
	 */

}
