package com.isg.asynchronous.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@PropertySource("classpath:messages.properties")
@PropertySource("classpath:appconfig.properties")
@PropertySource("classpath:log4j2.component.properties")
@Configuration
public class PropertyUtils {

	@Autowired
	private Environment envTmp;

	private static Environment env;

	public static String getProperty(String key) {
		return env.getProperty(key);
	}

	@PostConstruct
	public void afterInit() {
		PropertyUtils.env = envTmp;
	}

}