package com.isg.observer;

public interface Subject {

	void registeredAcc(Customer customer);

	void deletedAcc(Observer customer);

	void notifyAllCustomers();

	void upload(String bankBranch);

}