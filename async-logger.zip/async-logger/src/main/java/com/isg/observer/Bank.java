package com.isg.observer;

import java.util.ArrayList;
import java.util.List;

public class Bank implements Subject {
	
	private List<Customer> cust = new ArrayList();
    String bankBranch;
	
	@Override
	public void registeredAcc(Customer customer) 
	{
		cust.add(customer);
	}
	
	@Override
	public void deletedAcc(Observer customer)
	{
		cust.remove(customer);
	}
	
	@Override
	public void notifyAllCustomers()
	{
		for(Observer customer : cust)
		{
			customer.update();
		}
	}
	
	@Override
	public void upload(String bankBranch) 
	{
		this.bankBranch = bankBranch;
		notifyAllCustomers();
	}

}
