package com.isg.observer;

public class Government {
	
	public static void main(String[] args) 
	{
		Bank hdfc = new Bank();
		
		Customer c1 = new Customer("Neha");
		Customer c2 = new Customer("Raman");
		Customer c3 = new Customer("Ronee");
		
		hdfc.registeredAcc(c1);
		hdfc.registeredAcc(c2);
		hdfc.registeredAcc(c3);
		
		hdfc.deletedAcc(c2);
		
		c1.customerAdd(hdfc);
		c2.customerAdd(hdfc);
		c3.customerAdd(hdfc);
		
		hdfc.upload("hdfc andheri");
		
	}
	

}
