package com.isg.observer;

public class Customer implements Observer {
	
	private String name;
	private Bank bank = new Bank();
	
	
	
	public Customer(String name) {
		super();
		this.name = name;
	}

	@Override
	public void update()
	{
		System.out.println("hey " + name + ", new bank branch introduced " + bank.bankBranch);
	}
	
	@Override
	public void customerAdd(Bank name) 
	{
		bank = name;
	}
	
	
}
