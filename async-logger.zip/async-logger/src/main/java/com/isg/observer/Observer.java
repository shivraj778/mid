package com.isg.observer;

public interface Observer {

	void update();

	void customerAdd(Bank name);

}