package com.isg.education;

public class Student implements Observer {
	private String course;
	private int fees;
	private String duration;
	
	private static int observerIDTracker = 0;
	
	private int observerID;
	
	private Subject subject;
	
	public Student(Subject sub) 
	{
		this.subject = sub;
		this.observerID = ++observerIDTracker;
		System.out.println("new observer" + this.observerID);
		subject.register(this);
	}

	@Override
	public void update(String course, int fees, String duration) {
		this.course = course;
		this.fees = fees;
		this.duration = duration;
		
		printNewData();
	}
	
	public void printNewData() 
	{
		System.out.println("Course: " + course + "\nFees: " + fees + "\nDuration: " + duration);
	}

}
