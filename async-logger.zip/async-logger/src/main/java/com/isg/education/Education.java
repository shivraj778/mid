package com.isg.education;

public class Education {
	public static void main(String[] args) {
		Collage clg = new Collage();
		
		Student stu1 = new Student(clg);
		
		clg.setCourse("java");
		clg.setFees(1200);
		clg.setDuration("3 months");
		
		Student stu2 = new Student(clg);
		
		clg.setCourse("angular");
		clg.setFees(1500);
		clg.setDuration("6 months");
		
		
	}

}
