package com.isg.education;

import java.util.ArrayList;

public class Collage implements Subject {
	private ArrayList<Observer> observers;
	private String course;
	private int fees;
	private String duration;
	
	

	public Collage() {
		observers = new ArrayList<Observer>();
	}

	@Override
	public void register(Observer newObserver) {
		
		observers.add(newObserver);
	}

	@Override
	public void unRegister(Observer deleteObserver) {
		int observerIndex = observers.indexOf(deleteObserver);
		System.out.println("observer " + (observerIndex+1) + "deleted");
		observers.remove(deleteObserver);
		}

	@Override
	public void notifyObserver() {
		
		for(Observer observer : observers) 
		{
			observer.update(course, fees, duration);
		}
		
	}
	
	public void setCourse(String newCourse) {
		this.course = newCourse;
		notifyObserver();
	}
	
	public void setFees(int newFees) {
		this.fees = newFees;
		notifyObserver();
	}
	
	public void setDuration(String newDuration) {
		this.duration = newDuration;
		notifyObserver();
	}
	

}
