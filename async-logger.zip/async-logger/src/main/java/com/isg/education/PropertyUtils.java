package com.isg.education;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@PropertySource("classpath:jsonData1.txt")
@Configuration
public class PropertyUtils {

	@Autowired
	private Environment envTmp;

	private static Environment env;

	public static String getProperty(String key) {
		return env.getProperty(key);
	}

	@PostConstruct
	public void afterInit() {
		PropertyUtils.env = envTmp;
	}

}