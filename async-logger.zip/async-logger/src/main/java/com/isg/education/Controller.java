package com.isg.education;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@PostMapping("/update")
	public void update() 
	{
		
	}
	

}
