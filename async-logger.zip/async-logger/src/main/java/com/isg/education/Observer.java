package com.isg.education;

public interface Observer {
	public void update(String course, int fees, String duration);

}
