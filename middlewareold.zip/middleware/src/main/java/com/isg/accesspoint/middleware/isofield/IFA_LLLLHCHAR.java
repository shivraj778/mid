package com.isg.accesspoint.middleware.isofield;

import org.jpos.iso.AsciiInterpreter;
import com.isg.accesspoint.middleware.prefixer.AsciiPrefixer;
import org.jpos.iso.HEXInterpreter;
import org.jpos.iso.ISOStringFieldPackager;
import org.jpos.iso.NullPadder;

public class IFA_LLLLHCHAR extends ISOStringFieldPackager {
	
	public IFA_LLLLHCHAR() {
		super(NullPadder.INSTANCE, AsciiInterpreter.INSTANCE, AsciiPrefixer.LLLL);
	}

	/**
	 * @param len         - field len
	 * @param description symbolic descrption
	 */
	public IFA_LLLLHCHAR(int len, String description) {
		super(len, description, NullPadder.INSTANCE, AsciiInterpreter.INSTANCE, AsciiPrefixer.LLLL);
		checkLength(len, 9999);
	}

	public void setLength(int len) {
		checkLength(len, 9999);
		super.setLength(len);
	}
}