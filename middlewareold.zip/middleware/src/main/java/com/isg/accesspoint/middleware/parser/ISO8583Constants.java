package com.isg.accesspoint.middleware.parser;

public interface ISO8583Constants {
	

	static final String MSG_LENGTH = "msgLength";
	String MTI = "MTI";
	String TDPU = "tdpu";
	String BITMAP = "Bitmap";
	String DE002 = "DE002";
	String DE003 = "DE003";
	String DE004 = "DE004";
	String DE011 = "DE011";
	String DE022 = "DE022";
	String DE024 = "DE024";
	String DE025 = "DE025";
	String DE035 = "DE035";
	String DE041 = "DE041";
	String DE042 = "DE042";
	String DE052 = "DE052";
	String DE053 = "DE053";
	String DE054 = "DE054";
	String DE062 = "DE062";
	String DE063 = "DE063";
}
