package com.isg.accesspoint.middleware;

import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class log1 {
	
	
	 

	public static void main(String[] args) {
		
		Logger logger = LoggerFactory.getLogger(log1.class);
		
		logger.trace("Trace Message!");
	      logger.debug("Debug Message!");
	      logger.info("Info Message!");
	      logger.warn("Warn Message!");
	      logger.error("Error Message!");
		/* logger.fatal("Fatal Message!"); */
		
	     
       
	}

}
