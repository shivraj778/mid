package com.isg.accesspoint.middleware.isofield;

import org.jpos.iso.ISOStringFieldPackager;
import org.jpos.iso.NullPadder;
import org.jpos.iso.NullPrefixer;

import com.isg.accesspoint.middleware.interpreter.HexToAsciiInterpreter;
import com.isg.accesspoint.middleware.prefixer.AsciiPrefixer;

public class IFH_LLLLACHAR extends ISOStringFieldPackager {

	public IFH_LLLLACHAR() {
		super(NullPadder.INSTANCE, HexToAsciiInterpreter.INSTANCE, AsciiPrefixer.LLLL);
	}

	/**
	 * @param len         - field len
	 * @param description symbolic descrption
	 */
	public IFH_LLLLACHAR(int len, String description) {
		super(len, description, NullPadder.INSTANCE, HexToAsciiInterpreter.INSTANCE, AsciiPrefixer.LLLL);
		checkLength(len, 9999);
	}

	public void setLength(int len) {
		checkLength(len, 9999);
		super.setLength(len);
	}
}