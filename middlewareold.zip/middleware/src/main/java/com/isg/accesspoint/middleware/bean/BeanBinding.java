package com.isg.accesspoint.middleware.bean;


import org.apache.camel.builder.RouteBuilder;
import org.apache.logging.log4j.LogManager;
/*import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;



public class BeanBinding extends RouteBuilder{
	
	private Logger logger = LogManager.getLogger(getClass());

	@Value("${tcpclient.ip}")
	private String tcpClientIp;

	@Value("${tcpserver.ip}")
	private String tcpServerIp;

	@Value("${tcpToKafkaRouteTopic}")
	private String transactionRequestTopic;

	@Value("${kafka.brokers}")
	private String kafkaBrokers;
	
	

	@Override
	public void configure() throws Exception {
		
		from("netty:tcp://" + tcpClientIp + "?sync=false&textline=true")
			
		.bean(new Bean1(),"transaction01")
		.multicast().parallelProcessing()
		.to("direct:kafka-raw", "direct:tcp-server")
//		.to("direct:tcp-server")
		.end();
		
		
		from("direct:kafka-raw")			
		.bean(new Bean1(),"transaction02")
		.to("kafka:" + "sale-request-raw" + "?brokers=" + kafkaBrokers)
		.bean(new Bean1(),"transaction03")
		.marshal().json()
		.to("kafka:" + transactionRequestTopic + "?brokers=" + kafkaBrokers);
		 
		
		from("direct:tcp-server")		
		.bean(new Bean1(),"transaction04")
		.to("netty:tcp://" + tcpServerIp + "?sync=false&textline=true");
	}

}
