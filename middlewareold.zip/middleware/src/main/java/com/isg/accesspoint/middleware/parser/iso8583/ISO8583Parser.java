package com.isg.accesspoint.middleware.parser.iso8583;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.jpos.util.Logger;
import org.jpos.util.SimpleLogListener;

public class ISO8583Parser //implements Processor 
{

	/*@Override
	public void process(Exchange exchange) throws Exception {
		// TODO Auto-generated method stub
		
	     String strIsoData = exchange.getIn().getBody(String.class);
	        String newbody=strIsoData.replace(" ", "").replace("\n", "");

	        System.out.println(newbody);
	        
	        parse(newbody);
	        

	}
	*/

	/* private void parse(String isoMssg) throws ISOException {
		 
		 GenericPackager packager=new GenericPackager("src/main/resources/fields.xml");
            Logger  logger = new Logger();
            logger.addListener(new SimpleLogListener());
		 String msg=isoMssg;
		 System.out.println("DATA : "+msg);
		 //Create ISO Message
		  ISOMsg isoMsg=new ISOMsg();
		  isoMsg.setPackager(packager);
		  packager.setLogger(logger, "fields");
		  isoMsg.unpack(msg.getBytes());
		 
		 
	 }*/
	
	public  void process1(String msg) throws ISOException {
		
		String MSG = msg;
		 String newbody=MSG.replace(" ", "").replace("\n", "");

	        System.out.println(newbody);
	        
	          parse(newbody);
	       
		
		
	}
	private void parse(String isoMssg) throws ISOException {
		
		GenericPackager packager=new GenericPackager("src/main/resources/fields.xml");
        Logger  logger = new Logger();
        logger.addListener(new SimpleLogListener());
	 String msg=isoMssg;
	 System.out.println("DATA : "+msg);
	 //Create ISO Message
	  ISOMsg isoMsg=new ISOMsg();
	  isoMsg.setPackager(packager);
	  packager.setLogger(logger, "fields");
	   isoMsg.unpack(msg.getBytes());
		
	}
	
	
	 



}


