package com.isg.accesspoint.middleware.bean;

import java.io.IOException;


import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.isg.accesspoint.common.bean.ISO8583;
import com.isg.accesspoint.middleware.parser.ISO8583Parser;
import com.isg.accesspoint.middleware.service.TransactionRequestRouteService;

public class Bean1 {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private TransactionRequestRouteService routeService;
	

	
	public void transaction01(Exchange exchange)
	{
		String transactionMsg = (String) exchange.getIn().getBody();
		if (transactionMsg == null) {
			// stopping the further route processing, since msg is null
			exchange.setProperty(Exchange.ROUTE_STOP, Boolean.TRUE);
		}
		
	}
	
	public void transaction02(Exchange exchange) throws JsonProcessingException
	{
		
		String transactionMsg = (String) exchange.getIn().getBody();
		ObjectMapper mapper = new ObjectMapper();
		String txnId = routeService.getTransactionId();
		ObjectNode transaction = mapper.createObjectNode();
		transaction.put("txnId", txnId);
		transaction.put("rawMsg", transactionMsg);//assign raw msg value to 
		exchange.getIn().setBody(mapper.writeValueAsString(transaction));
	}
	
	public void transaction03(Exchange exchange) {
		
		
		String body = (String) exchange.getIn().getBody();
		
		ObjectMapper objectMapper = new ObjectMapper();
		ISO8583 iso8583Obj = null;
		try {
			iso8583Obj = objectMapper.readValue(body, ISO8583.class);
		} catch (IOException e) {
			logger.debug("Error while reading the transaction", e);
		}
		String parsedMsg = ISO8583Parser.parse(iso8583Obj.getRawMsg());
		ISO8583 toIso8583Obj = routeService.toISO8583Object(parsedMsg);
		toIso8583Obj.setTxnId(iso8583Obj.getTxnId());
		exchange.getIn().setBody(toIso8583Obj);
		logger.info("Parsed message to kafka {}", toIso8583Obj);
	}
	
	public void transaction04(Exchange exchange) {
		String transactionMsg = (String) exchange.getIn().getBody();
		logger.info("Message received from TCP Client: {}", transactionMsg);
		String parsedMsg = ISO8583Parser.parse(transactionMsg);
		logger.info("Message parsed using JPOS library: {}", parsedMsg);
		exchange.getIn().setBody(parsedMsg);
	}

}
