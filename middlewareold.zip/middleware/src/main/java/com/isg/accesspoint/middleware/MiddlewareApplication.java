package com.isg.accesspoint.middleware;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.isg.accesspoint.middleware.routes.TransactionRequestTCPRoute;

@SpringBootApplication
public class MiddlewareApplication {

	public static void main(String[] args) throws Exception {
		
		  SpringApplication.run(MiddlewareApplication.class, args);
		 // System.out.println("main");
		 

		/*
		 * CamelContext context = new DefaultCamelContext(); context.addRoutes(new
		 * TransactionRequestTCPRoute()); context.start(); Thread.sleep(3 * 60 * 1000);
		 * context.stop();
		 */

	}

	/*
	 * @Bean ServletRegistrationBean servletRegistrationBean() {
	 * ServletRegistrationBean servlet = new ServletRegistrationBean(new
	 * CamelHttpTransportServlet(), "/camel/*"); servlet.setName("CamelServlet");
	 * return servlet; }
	 */

}
