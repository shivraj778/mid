package com.isg.accesspoint.middleware.service;

import java.io.IOException;
import java.time.LocalDateTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.accesspoint.common.bean.ISO8583;
import com.isg.accesspoint.common.utils.Util;

@Component
public class TransactionRequestRouteService {

	//private Logger logger = LoggerFactory.getLogger(getClass());
	private Logger logger = LogManager.getLogger(getClass());

	public ISO8583 toISO8583Object(String body) {
		ObjectMapper objectMapper = new ObjectMapper();
		ISO8583 iso8583Obj = null;
		try {
			iso8583Obj = objectMapper.readValue(body, ISO8583.class);
		} catch (IOException e) {
			logger.debug("Error while converting to ISO8583 object", e);
		}
		return iso8583Obj;
	}
	
	public String getTransactionId() {
		return Util.formatDate(LocalDateTime.now(), "yyyyMMddss");
	}

}