package com.isg.accesspoint.middleware.routes;


import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.isg.accesspoint.middleware.bean.Bean1;
import com.isg.accesspoint.middleware.service.TransactionRequestRouteService;

@Component
public class TransactionRequestTCPRoute extends RouteBuilder {

	//private Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${tcpclient.ip}")
	private String tcpClientIp;

	@Value("${tcpserver.ip}")
	private String tcpServerIp;

	/*
	 * @Value("${tcpToKafkaRouteTopicraw}") private String
	 * transactionRequestTopicraw;
	 * 
	 * @Value("${tcpToKafkaRouteTopiciso8583}") private String
	 * transactionRequestTopiciso8583;
	 * 
	 * @Value("${kafka.brokers}") private String kafkaBrokers;
	 */
	
	@Autowired
	private TransactionRequestRouteService routeService;



	public void configure() throws Exception {
		
		from("netty:tcp://" + tcpClientIp + "?sync=false&textline=true")
			
		.bean(Bean1.class,"transaction01(${exchange})")
		.multicast().parallelProcessing()
		//.to("direct:kafka-raw", "direct:tcp-server")
	.to("direct:tcp-server")
		.end();
		
		/*
		 * from("direct:kafka-raw") .bean(Bean1.class,"transaction02(${exchange})")
		 * .to("kafka:" + "transactionRequestTopicraw" + "?brokers=" + kafkaBrokers)
		 * .bean(Bean1.class,"transaction03(${exchange})") .marshal().json()
		 * .to("kafka:" + transactionRequestTopiciso8583 + "?brokers=" + kafkaBrokers);
		 */
		 
		
		from("direct:tcp-server")		
		.bean(Bean1.class,"transaction04(${exchange})")
		.to("netty:tcp://" + tcpServerIp + "?sync=false&textline=true");
	}

}
