package com.isg.accesspoint.middleware.parser;

import java.io.InputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
//import org.jpos.util.Logger;
//import org.jpos.util.SimpleLogListener;
//import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ISO8583Parser {

	private static Logger logger = LogManager.getLogger(ISO8583Parser.class);

	/**
	 * Parses the given transaction string using JPOS library and then converts to
	 * JSON string.
	 * 
	 * @param str String to be parsed
	 * @return Returns the JSON string
	 * @throws Exception
	 */
	public static String parse(String str) {
		if (str == null || str.trim().isEmpty()) {
			logger.info("Message is empty");
			return null;
		}
		String resJson = null;
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode transaction = mapper.createObjectNode();
		try {
			// Trimming out first 14 characters which includes length and TPDU value
			str = str.trim().replace(" ", "").substring(14);
			InputStream is = ISO8583Parser.class.getResourceAsStream("/fields.xml");
			GenericPackager packager = new GenericPackager(is);
			ISOMsg isoMsg = new ISOMsg();
			isoMsg.setPackager(packager);
			isoMsg.unpack(str.getBytes());

			ArrayNode dataElementsArr = mapper.createArrayNode();
			transaction.put("mti", isoMsg.getMTI());

			ObjectNode dataElementsNode = mapper.createObjectNode();

			for (int i = 1; i <= isoMsg.getMaxField(); i++) {
				if (isoMsg.hasField(i)) {
					String fieldId = "de" + "000".substring(String.valueOf(i).length()) + i;
					dataElementsNode.put(fieldId, isoMsg.getString(i));
				}
			}
			dataElementsArr.add(dataElementsNode);
			transaction.putPOJO("dataElements", dataElementsArr);

		} catch (ISOException e) {
			logger.error("Error while parsing the message", e);
		}
		try {
			resJson = mapper.writeValueAsString(transaction);
		} catch (JsonProcessingException e) {
			logger.error("Error while writing the message into JSON", e);
		}
		return resJson;
	}
}