package com.isg.accesspoint.middleware.interpreter;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.Interpreter;

public class HexToAsciiInterpreter implements Interpreter {

	public static final HexToAsciiInterpreter INSTANCE = new HexToAsciiInterpreter();

	@Override
	public void interpret(String data, byte[] b, int offset) throws ISOException {

	}

	@Override
	public String uninterpret(byte[] rawData, int offset, int length) throws ISOException {
		String str = new String(rawData, offset, length, ISOUtil.CHARSET);
		return convertHexToString(str);
	}

	public String convertHexToString(String hex) {

		StringBuilder sb = new StringBuilder();
		StringBuilder temp = new StringBuilder();
		// 49204c6f7665204a617661 split into two characters 49, 20, 4c...
		for (int i = 0; i < hex.length() - 1; i += 2) {

			// grab the hex in pairs
			String output = hex.substring(i, (i + 2));
			// convert hex to decimal
			int decimal = Integer.parseInt(output, 16);
			// convert the decimal to character
			sb.append((char) decimal);

			temp.append(decimal);
		}
		return sb.toString();
	}

	@Override
	public int getPackedLength(int nDataUnits) {
		return nDataUnits;
	}

}