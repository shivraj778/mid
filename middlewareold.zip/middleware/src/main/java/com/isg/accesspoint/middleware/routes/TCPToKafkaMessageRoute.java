package com.isg.accesspoint.middleware.routes;

import org.apache.camel.builder.RouteBuilder;


import com.isg.accesspoint.middleware.parser.iso8583.ISO8583Parser;


public class TCPToKafkaMessageRoute extends RouteBuilder{

    @Override
    public void configure() throws Exception {
from("netty:tcp://192.168.37.26:8080?textline=true&sync=true")
        .to("log:?level=INFO&showBody=true")
        // .process(new ISO8583Parser());
//.to("kafka:ttopic_name?brokers=localhost:9092,netty:tcp://localhost:8081?textline=true&sync=true");
        .bean(new ISO8583Parser());
    } 

}
