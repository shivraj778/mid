package com.isg.accesspoint.middleware.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.CsvDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.isg.accesspoint.common.model.User;

//@Component
public class RestApi extends RouteBuilder {

	@Override
	public void configure() {

		String name = "abc";
//		from("rest:get:kafka/publish/{name}?host=localhost:8080")
//		from("netty-http:http://localhost:8081/kafka?myParam=myValue")
//		from("netty:tcp://192.168.37.40:30?sync=false")
		from("file:/home/backup/20-Jan/?noop=true&fileName=users.csv")
		.log("Consumed msg")
		.unmarshal(new CsvDataFormat())
//		.bindy(BindyType.Csv, User.class)
		  .process(new Processor() {
		  
		  @Override public void process(Exchange exchange) throws Exception {
//			  System.out.println(exchange.getPattern());
			  Message in = exchange.getIn();
			  List<List<String>> data = (List<List<String>>)in.getBody();
//			  System.out.println(data);
			  List<User> users = new ArrayList<>();
			for (List<String> allCsvData : data) {
//				System.out.println(allCsvData);
				User user = new User();
//					String[] split = userData.split(",");
				user.setName(allCsvData.get(0));
				user.setDept(allCsvData.get(1));
				user.setSalary(Long.valueOf(allCsvData.get(2)));
				users.add(user);
				exchange.getMessage().setBody(user);
			}
			  System.out.println(users);
//			  exchange.getMessage().setBody(users);
		  	} 
		  }).marshal().json(JsonLibrary.Jackson)
//			.setBody(() ->{
//				return new User("Bob", "Tech", 5000L);// Message to send
//			})
//			.setHeader(KafkaConstants.KEY, constant("Camel")) // Key of the message
				.to("kafka:akshay_producer?brokers=192.168.37.41:9092,192.168.37.24:9092,192.168.37.29:9092")
				.process(new Processor() {
					
					@Override
					public void process(Exchange exchange) throws Exception {
//						User user = (User) exchange.getIn().getBody();
//						System.out.println(user);
					}
				})
				.log("consumed msg in kafka");

	}
}