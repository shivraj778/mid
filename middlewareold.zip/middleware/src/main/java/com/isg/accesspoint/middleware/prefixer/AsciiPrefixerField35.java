package com.isg.accesspoint.middleware.prefixer;

import org.jpos.iso.ISOException;
import org.jpos.iso.Prefixer;

public class AsciiPrefixerField35 implements Prefixer {
	
	public static final AsciiPrefixerField35 LLLL = new AsciiPrefixerField35(4);

	public static final AsciiPrefixerField35 LL = new AsciiPrefixerField35(2);
	
	private int nDigits;
    
    public AsciiPrefixerField35(int nDigits)
    {
        this.nDigits = nDigits;
    }

	@Override
	public void encodeLength(int length, byte[] b) throws ISOException {
		
	}

	@Override
	public int decodeLength(byte[] b, int offset) throws ISOException {
		int len = 0;
        for (int i = 0; i < nDigits; i++)
        {
            byte d = b[offset + i];
            if(d < '0' || d > '9')
            {
                throw new ISOException("Invalid character found. Expected digit.");
            }
            len = len * 10 + d - (byte)'0';
        }
        return len * 2;
	}

	@Override
	public int getPackedLength() {
		// TODO Auto-generated method stub
		return nDigits;
	}

}