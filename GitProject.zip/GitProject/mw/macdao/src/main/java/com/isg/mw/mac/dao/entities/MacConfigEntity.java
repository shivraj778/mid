package com.isg.mw.mac.dao.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.Status;

import lombok.Getter;
import lombok.Setter;

/**
 * Mac configuration details
 * 
 * @author shivraj3987
 *
 */
@Getter
@Setter
@Entity
@Table(name = "MAC_CONFIG")
public class MacConfigEntity {

	/**
	 * Primary id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	/**
	 * Name of config
	 */
	@Column(name = "NAME", length = 30)
	private String name;

	/**
	 * Message format
	 */
	@Column(name = "MESSAGE_FORMAT", length = 15)
	private String messageFormat;

	/**
	 * Name of the switch configuration
	 */
	@Column(name = "DEFAULT_SWITCH", length = 30)
	private String defaultSwitch;

	/**
	 * Merchant prefrences
	 */
	@Column(name = "MERCHANT_PREFERENCE", length = 62)
	private String merchantPreferences;

	/**
	 * List of prefered switches
	 */
	@Column(name = "SWITCH_PREFERENCES", length = 154)
	private String switchPreferences;

	/**
	 * Connection type
	 */
	@Column(name = "CONNECTION_TYPE", length = 10)
	private ConnectionType type;

	/**
	 * Socket port number
	 */
	@Column(name = "PORT")
	private Integer port;

	/**
	 * Headers for web connection
	 */
	@Column(name = "HEADERS_INFO", length = 999)
	private String headersInfo;

	/**
	 * Encryption key
	 */
	@Column(name = "ENCRYPTION_KEY", length = 128)
	private String encryptionKey;

	/**
	 * Decryption key
	 */
	@Column(name = "DECRYPTION_KEY", length = 128)
	private String decryptionKey;

	/**
	 * Created date
	 */
	@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;

	/**
	 * Updated date
	 */
	@Column(name = "UPDATED_DATE")
	private LocalDateTime updatedDate;

	/**
	 * Status of the configuration
	 */
	@Column(name = "STATUS", length = 10)
	private Status status;

	/**
	 * Debug to store entire packet in database
	 */
	@Column(name = "DEBUG")
	private Boolean debug;

}
