package com.isg.mw.sw.dao.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.MessageFormat;
import com.isg.mw.core.model.constants.Status;

import lombok.Getter;
import lombok.Setter;

/**
 * Switch configuration details
 * 
 * @author shivraj3987
 *
 */

@Getter
@Setter
@Entity
@Table(name = "SWITCH_CONFIG")
public class SwitchConfigEntity {

	/**
	 * Primary id of the config
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	/**
	 * Name of the switch
	 */
	@Column(name = "NAME", length = 30)
	private String name;

	/**
	 * Message format
	 */
	@Column(name = "MESSAGE_FORMAT", length = 15)
	private MessageFormat messageFormat;

	/**
	 * Connection type
	 */
	@Column(name = "CONNECTION_TYPE", length = 10)
	private ConnectionType connectionType;

	/**
	 * Socket port number
	 */
	@Column(name = "PORT")
	private Integer port;

	/**
	 * Socket IP address
	 */
	@Column(name = "IP_ADDRESS", length = 64)
	private String ipAddress;

	/**
	 * URL
	 */
	@Column(name = "URL", length = 128)
	private String url;

	/**
	 * Headers info
	 */
	@Column(name = "HEADERS_INFO", length = 999)
	private String headersInfo;

	/**
	 * Encryption key
	 */
	@Column(name = "ENCRYPTION_KEY", length = 128)
	private Byte[] encryptionKey;

	/**
	 * Decryption key
	 */
	@Column(name = "DECRYPTION_KEY", length = 128)
	private Byte[] decryptionKey;

	/**
	 * Crate date
	 */
	@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;

	/**
	 * Update Date
	 */
	@Column(name = "UPDATED_DATE")
	private LocalDateTime updatedDate;

	/**
	 * Status about switch
	 */
	@Column(name = "STATUS", length = 10)
	private Status status;

}
