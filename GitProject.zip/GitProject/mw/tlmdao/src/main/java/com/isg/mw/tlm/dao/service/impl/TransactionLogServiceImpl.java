package com.isg.mw.tlm.dao.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.isg.mw.core.model.TransactionMessageModel;
import com.isg.mw.tlm.dao.entities.TransactionLogEntity;
import com.isg.mw.tlm.dao.repository.TransactionLogDao;
import com.isg.mw.tlm.dao.service.TransactionLogService;
import com.isg.mw.tlm.dao.utils.TransactionLogUtil;
/**
 * 
 * @author shivraj3987
 *
 */

@Service
public class TransactionLogServiceImpl implements TransactionLogService {
	@Autowired
	private TransactionLogDao tlmdao;
	
	/**
	 * 
	 */
	@Override
	public List<TransactionMessageModel> findAllByTxnId(String txnId) {
		List<TransactionLogEntity> entity = tlmdao.findByTxnId(txnId);
		List<TransactionMessageModel> model = new ArrayList<>();
		if (entity != null) {			
			for(TransactionLogEntity i: entity) {
				model.add(TransactionLogUtil.getTransactionModel(i));
			}
			return model;	
		}
		return Collections.emptyList();
		
	}

	@Override
	public TransactionMessageModel add(TransactionMessageModel transModel) {

		TransactionLogEntity entity = TransactionLogUtil.getTxnLogEntity(transModel);
		if (entity != null) {
			TransactionLogEntity savedEntity = tlmdao.save(entity);
			transModel.setTransactionId(String.valueOf(savedEntity.getTransactionId()));
			return transModel;
		}
		return null;

	}

	@Override
	public TransactionMessageModel update(TransactionMessageModel transModel) {

		List<TransactionLogEntity> txnLogEntityList = tlmdao.findByTxnId(transModel.getTransactionId());
		if (txnLogEntityList != null && !txnLogEntityList.isEmpty()) {
			TransactionLogUtil.updateTxnLogEntity(transModel, txnLogEntityList.get(0));
			TransactionLogEntity txnLogEntity = tlmdao.save(txnLogEntityList.get(0));
			transModel.setTransactionId(String.valueOf(txnLogEntity.getTransactionId()));
			return transModel;
		}

		return null;
	}

}
