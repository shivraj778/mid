package com.isg.mw.tlm.dao.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.mw.core.model.constants.MessageFormat;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * DB model of the Transaction Message All transaction messages
 * (Request/Response) will be stored in DataBase from this model
 * 
 * @author akshay3978
 */
@Setter
@Getter
@Data
@Entity
@Table(name = "TRANSACTION_LOG_MESSAGE")
public class TransactionLogEntity {

	/**
	 * Primary Key
	 */
	@Id
	@Column(name = "Id", length = 16)
	private long id;

	/**
	 * 2. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Primary account number<br>
	 * CyberSource API - Number<br>
	 * mPOS - CardNumber
	 */
	@Column(name = "PAN", length = 47)
	private String pan;

	/**
	 * 3.<br>
	 * ISO8583, AS2805, Base24, ISG, XML - Processing Code <br>
	 * CyberSource API - ProcessorId <br>
	 * mPOS - Transaction_Type
	 */
	@Column(name = "PROCESSING_CODE", length = 6)
	private String processingCode;

	/**
	 * 4. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Transaction Amount <br>
	 * CyberSource API - AuthorizedAmount <br>
	 * mPOS - Amount
	 */
	@Column(name = "TXN_AMT", columnDefinition = "double precision")
	private Double txnAmt;

	/**
	 * 5. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Settlement Amount
	 */
	@Column(name = "SETTLEMENT_AMT", columnDefinition = "double precision")
	private Double settlementAmt;

	/**
	 * 6. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Cardholder Billing Amount
	 */
	@Column(name = "CARD_HOLDER_BILLING_AMT", columnDefinition = "double precision")
	private Double cardHolderBillingAmt;

	/**
	 * 7. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Transmission Date and Time
	 */
	@Column(name = "TRANSMISSION_TIME", length = 10)
	private String transmissionTime;

	/**
	 * 8. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Cardholder Billing Fee Amount
	 */
	@Column(name = "CARD_HOLDER_BILLING_FEE", columnDefinition = "double precision")
	private Double cardHolderBillingFee;

	/**
	 * 9. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Settlement Conversion Rate
	 */
	@Column(name = "SETTLEMENT_CONVERSION_RATE", columnDefinition = "double precision")
	private Double settlementConversionRate;

	/**
	 * 10. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Cardholder Billing Conversion Rate
	 */
	@Column(name = "CARD_HOLDER_BILLING_CONVERSION_RATE", columnDefinition = "double precision")
	private Double cardholderBillingConversionRate;

	/**
	 * 11. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - System Trace Audit Number <br>
	 * CyberSource API - Tid <br>
	 * mPOS - System Trace Number
	 */
	@Column(name = "STAN", length = 6)
	private String stan;

	/**
	 * 12. <br>
	 * ISO8583, AS2805, Base24, ISG, XML, CyberSource API - Local Transaction Time
	 * <br>
	 * mPOS - Time
	 */
	@Column(name = "LOCAL_TXN_TIME", length = 6)
	private String localTxnTime;

	/**
	 * 13. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Local Transaction Date <br>
	 * mPOS-Date
	 */
	@Column(name = "LOCAL_TXN_DATE", length = 4)
	private String localTxnDate;

	/**
	 * 15. <br>
	 * ISO8583, AS2805, Base24, XML - Settlement Date <br>
	 */
	@Column(name = "SETTLEMENT_DATE", length = 4)
	private String settlementDate;

	/**
	 * 16. <br>
	 * ISO8583, AS2805, Base24, XML - Currency conversion date
	 */
	@Column(name = "CONVERSION_DATE", length = 4)
	private String conversionDate;

	/**
	 * 18. <br>
	 * ISO8583, AS2805, Base24, XML - Merchant Type <br>
	 * CyberSource API - Category Code
	 */
	@Column(name = "MERCHANT_TYPE", length = 4)
	private String merchantType;

	/**
	 * 19. <br>
	 * ISO8583, AS2805, Base24, XML - Acquiring Institution Country Code <br>
	 * CyberSource API - Country <br>
	 * mPOS - Terminal Country Code
	 */
	@Column(name = "AQUIRER_COUNTRY_CODE", length = 3)
	private String aquirerCountryCode;

	/**
	 * 20. <br>
	 * ISO8583, AS2805, Base24, XML - Country Code Primary Account Number Extended
	 */
	@Column(name = "PAN_EXTENDED_COUNTRY_CODE", length = 3)
	private String panExtendedCountryCode;

	/**
	 * 22. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Point of Service Entry Mode <br>
	 * CyberSource API - Entry Mode <br>
	 * mPOS - NFC Enabled
	 */
	@Column(name = "POS_ENTRY_MODE", length = 3)
	private String posEntryMode;

	/**
	 * 24. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Network International ID <br>
	 * CyberSource API-Type
	 */
	@Column(name = "NII_ID", length = 3)
	private String niiId;

	/**
	 * 25. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Point of service condition code
	 */
	@Column(name = "POS_CONDITION_CODE", length = 2)
	private String posConditionCode;

	/**
	 * 28. <br>
	 * ISO8583, AS2805, Base24, XML - Transaction Fee Amount
	 */
	@Column(name = "TXN_FEE", columnDefinition = "double precision")
	private Double txnFee;

	/**
	 * 29. <br>
	 * ISO8583, AS2805, Base24, XML - Settlement Fee Amount
	 */
	@Column(name = "SETTLEMENT_FEE", columnDefinition = "double precision")
	private Double settlementFee;

	/**
	 * 30. <br>
	 * ISO8583, AS2805, Base24, XML - Transaction Processing Fee Amount
	 */
	@Column(name = "TXN_PROCESSING_FEE", columnDefinition = "double precision")
	private Double txnProcessingFee;

	/**
	 * 31. <br>
	 * ISO8583, AS2805, Base24, XML - Settlement Processing Fee Amount
	 */
	@Column(name = "SETTLEMENT_PROCESSING_FEE", columnDefinition = "double precision")
	private Double settlementProcessingFee;

	/**
	 * 32. <br>
	 * ISO8583, AS2805, Base24, XML - Acquiring Institution Identification Code
	 */
	@Column(name = "ACQUIRER_ID_CODE", length = 11)
	private String aquirerIdCode;

	/**
	 * 33.<br>
	 * ISO8583, AS2805, Base24, XML - Forwarding Institution Identification Code
	 */
	@Column(name = "FORWARDING_INST_ID_CODE", length = 11)
	private String forwardingInstIdCode;

	/**
	 * 34.<br>
	 * ISO8583, AS2805, Base24, ISG, XML - Extended Primary Account Number
	 */
	@Column(name = "PAN_EXTENDED_DATA", length = 28)
	private String panExtended;

	/**
	 * 37. <br>
	 * ISO8583, AS2805, Base24, ISG, XML, mPOS - Retrieval Reference Number <br>
	 * CyberSource API - Transaction Id
	 */
	@Column(name = "RETRIEVAL_REF_NO", length = 30)
	private String retrievalRefNo;

	/**
	 * 38. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Authorization id response <br>
	 * mPOS - Auth Code
	 */
	@Column(name = "AUTH_ID_RES", length = 6)
	private String authIdRes;

	/**
	 * 39. <br>
	 * ISO8583, AS2805, Base24, ISG, XML, CyberSource API - Response Code <br>
	 * mPOS - Status Code
	 */
	@Column(name = "RES_CODE", length = 2)
	private String resCode;

	/**
	 * 40. <br>
	 * ISO8583, AS2805, Base24, ISG, XML - Service Restriction Code
	 */
	@Column(name = "SERVICE_RESTRICTION_CODE", length = 3)
	private String serviceRestrictionCode;

	/**
	 * 41. <br>
	 * ISO8583, AS2805, Base24, ISG, XML, CyberSource API -Card Acceptor Terminal Id
	 * <br>
	 * mPOS - TId
	 */
	@Column(name = "CARD_ACCEPTOR_TERMINAL_ID", length = 16)
	private String cardAcceptorTerminalId;

	/**
	 * 42. <br>
	 * ISO8583, AS2805, Base24, ISG, XML, CyberSource API - Card Acceptor Id <br>
	 * mPOS - Txn Id
	 */
	@Column(name = "CARD_ACCEPTOR_ID", length = 15)
	private String cardAcceptorId;

	/**
	 * 43.<br>
	 * ISO8583, AS2805, Base24, ISG, XML, CyberSource API - Card Acceptor
	 * Name/Location <br>
	 * mPOS - Mobile, eMail
	 */
	@Column(name = "CARD_ACCEPTOR_INFO", length = 40)
	private String cardAcceptorInfo;

	/**
	 * 49. <br>
	 * ISO8583, AS2805, Base24, XML - Transaction Currency Code <br>
	 * CyberSource API - Currency
	 */
	@Column(name = "TXN_CURRENCY_CODE", length = 3)
	private String txnCurrencyCode;

	/**
	 * 50. <br>
	 * ISO8583, AS2805, Base24, XML - Settlement Currency Code
	 */
	@Column(name = "SETTLEMENT_CURRENCY_CODE", length = 3)
	private String settlementCurrenyCode;

	/**
	 * 51. <br>
	 * ISO8583, AS2805, Base24, XML - Cardholder Billing Currency Code
	 */
	@Column(name = "CARD_HOLDER_BILLING_CURRENCY_CODE", length = 3)
	private String cardHolderBillingCurrencyCode;

	/**
	 * 54. <br>
	 * ISO8583, AS2805, Base24, ISG, XML- Additional Amount
	 */
	@Column(name = "ADDTIONAL_AMOUNTS", length = 120)
	private String additionalAmounts;

	/**
	 * 55. <br>
	 * ISO8583, AS2805, ISG, mPOS - Integrated Circuit Card (ICC) Related Data <br>
	 * Base24 - ISO Reserved <br>
	 * CyberSource API - EMV
	 */
	@Column(name = "ICC_DATA", length = 999)
	private String iccData;

	/**
	 * 56. <br>
	 * ISO8583, AS2805, Base24, XML - ISO Reserved
	 */
	@Column(name = "ISO_RESERVED", length = 999)
	private String isoReserved;

	/**
	 * 60. <br>
	 * ISO8583 - Reserved for national use <br>
	 * AS2805, XML - Reserved private <br>
	 * Base24 - Terminal Data
	 */
	@Column(name = "NATIONAL_RESERVED", length = 999)
	private String nationalReserved;

	/**
	 * 61. <Br>
	 * ISO8583, AS2805, ISG, XML- Reserved private <br>
	 * Base24 - ATM Card Issuer and Authorizer Data/POS Card Issuer and Authorizer
	 * Data
	 */
	@Column(name = "PRIVATE_RESERVED1", length = 999)
	private String privateReserved1;

	/**
	 * 62. <br>
	 * ISO8583, AS2805, ISG, XML - Reserved private <br>
	 * Base24 - Postal Code mPOS - Invoice No
	 */
	@Column(name = "PRIVATE_RESERVED2", length = 999)
	private String privateReserved2;

	/**
	 * 63. <br>
	 * ISO8583, AS2805, ISG, XML - Reserved private <br>
	 * Base24 - ATM PIN Offset / POS Additional Data
	 */
	@Column(name = "PRIVATE_RESERVED3", length = 999)
	private String privateReserved3;

	/**
	 * 69.<br>
	 * ISO8583, AS2805, Base24, XML - Settlement Institution Country Code
	 */
	@Column(name = "SETTLEMENT_COUNTRY_CODE", length = 3)
	private String settlementCountryCode;

	/**
	 * Transaction Id
	 */
	@Column(name = "TRANSACTION_ID", length = 20)
	private String transactionId;

	/**
	 * Request Received Time
	 */
	@Column(name = "REQUEST_RECEIVED_TIME")
	private LocalDateTime requestReceivedTime;

	/**
	 * Request Sent Time
	 */
	@Column(name = "REQUEST_SENT_TIME")
	private LocalDateTime requestSentTime;

	/**
	 * Response Received Time
	 */
	@Column(name = "RESPONSE_RECEIVED_TIME")
	private LocalDateTime responseReceivedTime;

	/**
	 * Response Sent Time
	 */
	@Column(name = "RESPONSE_SENT_TIME")
	private LocalDateTime responseSentTime;

	/**
	 * Source Type
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "SOURCE_TYPE", length = 15)
	private MessageFormat sourceType;

	/**
	 * Destination Type
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "DESTINATION_TYPE", length = 15)
	private MessageFormat destinationType;

	/**
	 * Merchant / Aggregator Configuration
	 */
	@Column(name = "MAC", columnDefinition = "Integer")
	private Long mac;

	/**
	 * Switch Configuration
	 */
	@Column(name = "SWC", columnDefinition = "Integer")
	private Long swc;

}