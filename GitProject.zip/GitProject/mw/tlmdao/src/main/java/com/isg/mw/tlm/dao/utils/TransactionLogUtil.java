package com.isg.mw.tlm.dao.utils;

import com.isg.mw.core.model.TransactionMessageModel;
import com.isg.mw.core.model.constants.MessageFormat;
import com.isg.mw.tlm.dao.entities.TransactionLogEntity;

import lombok.NonNull;

/**
 * 
 * @author shivraj3987
 *
 */

public class TransactionLogUtil {

	TransactionLogUtil() {

	}

	public static TransactionLogEntity getTxnLogEntity(@NonNull TransactionMessageModel model) {

		TransactionLogEntity entity = new TransactionLogEntity();

		entity.setPan(model.getPrimaryAccNo());
		entity.setProcessingCode(model.getProcessingCode());
		entity.setTxnAmt(getDoubleValue(model.getTxnAmt()));
		entity.setSettlementAmt(getDoubleValue(model.getSettlementAmt()));
		
		entity.setCardHolderBillingAmt(getDoubleValue(model.getCardholderBillingAmt()));
		entity.setTransmissionTime(model.getTransmissionTime());
		entity.setCardHolderBillingFee(getDoubleValue(model.getCardholderBillingFee()));
		
		entity.setSettlementConversionRate(getDoubleValue(model.getSettlementConversionRate()));
		entity.setCardholderBillingConversionRate(getDoubleValue(model.getCardholderBillingConversionRate()));
		entity.setStan(model.getStan());
		entity.setLocalTxnTime(model.getLocalTxnTime());
		entity.setLocalTxnDate(model.getLocalTxnDate());
		entity.setSettlementDate(model.getSettlementDate());
		entity.setConversionDate(model.getConversionDate());
		entity.setMerchantType(model.getMerchantType());
		entity.setAquirerCountryCode(model.getAquiringCountryCode());
		entity.setPanExtendedCountryCode(model.getPanExtendedCountryCode());
		entity.setPosEntryMode(model.getPosEntryMode());
		entity.setNiiId(model.getNiiId());
		entity.setPosConditionCode(model.getPosConditionCode());
		entity.setTxnFee(getDoubleValue(model.getTxnFee()));
		entity.setSettlementFee(getDoubleValue(model.getSettlementFee()));
		entity.setTxnProcessingFee(getDoubleValue(model.getTxnProcessingFee()));
		entity.setSettlementProcessingFee(getDoubleValue(model.getSettlementProcessingFee()));
		entity.setAquirerIdCode(model.getAquirerIdCode());
		entity.setForwardingInstIdCode(model.getForwardingInstIdCode());
		entity.setPanExtended(model.getPanExtended());
		entity.setRetrievalRefNo(model.getRetrievalRefNo());
		entity.setAuthIdRes(model.getAuthIdRes());
		entity.setResCode(model.getResCode());
		entity.setServiceRestrictionCode(model.getServiceRestrictionCode());
		entity.setCardAcceptorTerminalId(model.getCardAcceptorTerminalId());
		entity.setCardAcceptorId(model.getCardAcceptorId());
		entity.setCardAcceptorInfo(model.getCardAcceptorInfo());
		entity.setTxnCurrencyCode(model.getTxnCurrencyCode());
		entity.setSettlementCurrenyCode(model.getSettlementCurrenyCode());
		entity.setCardHolderBillingCurrencyCode(model.getCardHolderBillingCurrencyCode());
		entity.setAdditionalAmounts(model.getAdditionalAmts());
		entity.setIccData(model.getIccData());
		entity.setIsoReserved(model.getReserved56());
		entity.setNationalReserved(model.getTerminalData());
		entity.setPrivateReserved1(model.getCiad());
		entity.setPrivateReserved2(model.getPostalCode());
		entity.setPrivateReserved3(model.getAtmPinOffsetData());
		entity.setSettlementCountryCode(model.getSettlementCountryCode());
		entity.setTransactionId(model.getTransactionId());
		entity.setRequestReceivedTime(model.getRequestReceivedTime());
		entity.setRequestSentTime(model.getRequestSentTime());
		
		
		entity.setResponseReceivedTime(model.getResponseReceivedTime());
		entity.setResponseSentTime(model.getResponseSentTime());
		entity.setSourceType(MessageFormat.getMessageFormat(model.getSourceType()));
		entity.setDestinationType(MessageFormat.getMessageFormat(model.getDestinationType()));
		entity.setMac(model.getMac());
		entity.setSwc(model.getSwc());

		return entity;

	}

	public static void updateTxnLogEntity(@NonNull TransactionMessageModel model, TransactionLogEntity entity) {
		entity.setPan(model.getPrimaryAccNo());
		entity.setProcessingCode(model.getProcessingCode());
		entity.setTxnAmt(getDoubleValue(model.getTxnAmt()));
		entity.setSettlementAmt(getDoubleValue(model.getSettlementAmt()));
		
		entity.setCardHolderBillingAmt(getDoubleValue(model.getCardholderBillingAmt()));
		entity.setTransmissionTime(model.getTransmissionTime());
		entity.setCardHolderBillingFee(getDoubleValue(model.getCardholderBillingFee()));
		
		entity.setSettlementConversionRate(getDoubleValue(model.getSettlementConversionRate()));
		entity.setCardholderBillingConversionRate(getDoubleValue(model.getCardholderBillingConversionRate()));
		entity.setStan(model.getStan());
		entity.setLocalTxnTime(model.getLocalTxnTime());
		entity.setLocalTxnDate(model.getLocalTxnDate());
		entity.setSettlementDate(model.getSettlementDate());
		entity.setConversionDate(model.getConversionDate());
		entity.setMerchantType(model.getMerchantType());
		entity.setAquirerCountryCode(model.getAquiringCountryCode());
		entity.setPanExtendedCountryCode(model.getPanExtendedCountryCode());
		entity.setPosEntryMode(model.getPosEntryMode());
		entity.setNiiId(model.getNiiId());
		entity.setPosConditionCode(model.getPosConditionCode());
		entity.setTxnFee(getDoubleValue(model.getTxnFee()));
		entity.setSettlementFee(getDoubleValue(model.getSettlementFee()));
		entity.setTxnProcessingFee(getDoubleValue(model.getTxnProcessingFee()));
		entity.setSettlementProcessingFee(getDoubleValue(model.getSettlementProcessingFee()));
		entity.setAquirerIdCode(model.getAquirerIdCode());
		entity.setForwardingInstIdCode(model.getForwardingInstIdCode());
		entity.setPanExtended(model.getPanExtended());
		entity.setRetrievalRefNo(model.getRetrievalRefNo());
		entity.setAuthIdRes(model.getAuthIdRes());
		entity.setResCode(model.getResCode());
		entity.setServiceRestrictionCode(model.getServiceRestrictionCode());
		entity.setCardAcceptorTerminalId(model.getCardAcceptorTerminalId());
		entity.setCardAcceptorId(model.getCardAcceptorId());
		entity.setCardAcceptorInfo(model.getCardAcceptorInfo());
		entity.setTxnCurrencyCode(model.getTxnCurrencyCode());
		entity.setSettlementCurrenyCode(model.getSettlementCurrenyCode());
		entity.setCardHolderBillingCurrencyCode(model.getCardHolderBillingCurrencyCode());
		entity.setAdditionalAmounts(model.getAdditionalAmts());
		entity.setIccData(model.getIccData());
		entity.setIsoReserved(model.getReserved56());
		entity.setNationalReserved(model.getTerminalData());
		entity.setPrivateReserved1(model.getCiad());
		entity.setPrivateReserved2(model.getPostalCode());
		entity.setPrivateReserved3(model.getAtmPinOffsetData());
		entity.setSettlementCountryCode(model.getSettlementCountryCode());
		entity.setTransactionId(model.getTransactionId());
		entity.setRequestReceivedTime(model.getRequestReceivedTime());
		entity.setRequestSentTime(model.getRequestSentTime());
		
		
		entity.setResponseReceivedTime(model.getResponseReceivedTime());
		entity.setResponseSentTime(model.getResponseSentTime());
		entity.setSourceType(MessageFormat.getMessageFormat(model.getSourceType()));
		entity.setDestinationType(MessageFormat.getMessageFormat(model.getDestinationType()));
		entity.setMac(model.getMac());
		entity.setSwc(model.getSwc());
	}

	public static TransactionMessageModel getTransactionModel(@NonNull TransactionLogEntity entity) {

		TransactionMessageModel model = new TransactionMessageModel();

		model.setPrimaryAccNo(entity.getPan());
		model.setProcessingCode(entity.getProcessingCode());
		model.setTxnAmt(getString(entity.getTxnAmt()));
		model.setSettlementAmt(getString(entity.getSettlementAmt()));
        model.setCardholderBillingAmt(getString(entity.getCardHolderBillingAmt()));
		model.setTransmissionTime(entity.getTransmissionTime());
        model.setCardholderBillingFee(getString(entity.getCardHolderBillingFee()));
		model.setSettlementConversionRate(getString(entity.getSettlementConversionRate()));
		model.setCardholderBillingConversionRate(getString(entity.getCardholderBillingConversionRate()));
		model.setStan(entity.getStan());
		model.setLocalTxnTime(entity.getLocalTxnTime());
		model.setLocalTxnDate(entity.getLocalTxnDate());

		model.setSettlementDate(entity.getSettlementDate());
		model.setConversionDate(entity.getConversionDate());

		model.setMerchantType(entity.getMerchantType());
		model.setAquiringCountryCode(entity.getAquirerCountryCode());
		model.setPanExtendedCountryCode(entity.getPanExtendedCountryCode());

		model.setPosEntryMode(entity.getPosEntryMode());

		model.setNiiId(entity.getNiiId());
		model.setPosConditionCode(entity.getPosConditionCode());
		

		model.setTxnFee(getString(entity.getTxnFee()));
		model.setSettlementFee(getString(entity.getSettlementFee()));
		model.setTxnProcessingFee(getString(entity.getTxnProcessingFee()));
		model.setSettlementProcessingFee(getString(entity.getSettlementProcessingFee()));
		model.setAquirerIdCode(entity.getAquirerIdCode());
		model.setForwardingInstIdCode(entity.getForwardingInstIdCode());
		model.setPanExtended(entity.getPanExtended());

		model.setRetrievalRefNo(entity.getRetrievalRefNo());
		model.setAuthIdRes(entity.getAuthIdRes());
		model.setResCode(entity.getResCode());
		model.setServiceRestrictionCode(entity.getServiceRestrictionCode());
		model.setCardAcceptorTerminalId(entity.getCardAcceptorTerminalId());
		model.setCardAcceptorId(entity.getCardAcceptorId());
		model.setCardAcceptorInfo(entity.getCardAcceptorInfo());

		model.setTxnCurrencyCode(entity.getTxnCurrencyCode());
		model.setSettlementCurrenyCode(entity.getSettlementCurrenyCode());
		model.setCardHolderBillingCurrencyCode(entity.getCardHolderBillingCurrencyCode());

		model.setAdditionalAmts(entity.getAdditionalAmounts());
		model.setIccData(entity.getIccData());
		model.setReserved56(entity.getIsoReserved());

		model.setTerminalData(entity.getNationalReserved());
		model.setCiad(entity.getPrivateReserved1());
		model.setPostalCode(entity.getPrivateReserved2());
		model.setAtmPinOffsetData(entity.getPrivateReserved3());

		model.setSettlementCountryCode(entity.getSettlementCountryCode());

		model.setTransactionId(entity.getTransactionId());
		model.setRequestReceivedTime(entity.getRequestReceivedTime());
		model.setRequestSentTime(entity.getRequestSentTime());
		model.setResponseReceivedTime(entity.getResponseReceivedTime());
		model.setResponseSentTime(entity.getResponseSentTime());
		model.setSourceType(convertMsgToString(entity.getSourceType()));
		model.setDestinationType(convertMsgToString(entity.getDestinationType()));
		model.setMac(entity.getMac());
		model.setSwc(entity.getSwc());
        
		return model;

	}
	
	private static String convertMsgToString(MessageFormat message) {
		String value;
		if(message != null) {
			value = message.name();
			return value;
		}
		return null;
	}

	private static String getString(Double doubleValue) {
		String value;
		if (doubleValue != null) {
			value = Double.toString(doubleValue);
			return value;
		}
		value = "0.0";
		return value;
	}

	

	private static Double getDoubleValue(String value) {
		if (value != null && value.length() > 0) {
			return Double.valueOf(value);
		}
		return 0.0;
	}



}
