package com.isg.mw.tlm.dao.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.isg.mw.tlm.dao.entities.TransactionLogEntity;
/**
 * 
 * @author shivraj3987
 *
 */

public interface TransactionLogDao extends CrudRepository<TransactionLogEntity, Long> {

	@Query("from TransactionLogEntity where TRANSACTION_ID:=txnId")
	List<TransactionLogEntity> findByTxnId(String txnId);

}
