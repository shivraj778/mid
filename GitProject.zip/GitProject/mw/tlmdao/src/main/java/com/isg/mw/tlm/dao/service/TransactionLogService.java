package com.isg.mw.tlm.dao.service;

import java.util.List;
import com.isg.mw.core.model.TransactionMessageModel;
/**
 * 
 * @author shivraj3987
 *
 */
public interface TransactionLogService {

	public List<TransactionMessageModel> findAllByTxnId(String txnId);

	public TransactionMessageModel add(TransactionMessageModel data);

	public TransactionMessageModel update(TransactionMessageModel data);

}
