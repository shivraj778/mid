package com.isg.mw.tlm.dao.service.impl.test;

import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.isg.mw.core.model.TransactionMessageModel;
import com.isg.mw.tlm.dao.entities.TransactionLogEntity;
import com.isg.mw.tlm.dao.repository.TransactionLogDao;
import com.isg.mw.tlm.dao.service.impl.TransactionLogServiceImpl;
import com.isg.mw.tlm.dao.utils.TransactionLogUtil;
/**
 * 
 * @author shivraj3987
 *
 */

public class TransactionMessageEntityServiceImplTest {

	@Mock
	TransactionLogUtil util;

	@InjectMocks
	TransactionLogServiceImpl trans;

	@Mock
	private TransactionLogDao transDao;

	TransactionMessageModel model = new TransactionMessageModel();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void test1() {
		Mockito.when(transDao.save(Mockito.any())).thenReturn(getTransactionMessageEntity());
		TransactionMessageModel value = trans.add(getmodel());
		assertNotNull(value.getTransactionId());
	}
	
	@Test
	public void test2() {
		Mockito.when(transDao.findByTxnId(Mockito.any())).thenReturn(getTransactionLog());
		Mockito.when(transDao.save(Mockito.any())).thenReturn(getTransactionMessageEntity());
		TransactionMessageModel value = trans.update(getmodel());
		assertNotNull(value.getTransactionId());
	}
	
	@Test
	public void test3()
	{
		Mockito.when(transDao.findByTxnId(Mockito.any())).thenReturn(getTransactionLog());
		List<TransactionMessageModel> list = trans.findAllByTxnId(Mockito.anyString());
		assertNotNull(list);
	}
	

	private TransactionLogEntity getTransactionMessageEntity() {
		TransactionLogEntity entity = new TransactionLogEntity();
		entity.setId(1);
		
		return entity;
	}
	private List<TransactionLogEntity> getTransactionLog()
	{
		List<TransactionLogEntity> list = new ArrayList<>();
		list.add(getTransactionMessageEntity());
		return list;
	}

	private TransactionMessageModel getmodel() {
		TransactionMessageModel model = new TransactionMessageModel();
		model.setNationalAd("India");
		model.setTxnAmt("123214.34");
		model.setActionDate("170513");
		return model;
	}

}
