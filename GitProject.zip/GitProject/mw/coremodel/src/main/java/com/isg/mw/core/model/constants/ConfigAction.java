package com.isg.mw.core.model.constants;

/**
 * Configuration actions
 * 
 * @author prasad_t026
 *
 */
public enum ConfigAction {

	ADD,
	
	UPDATE,
	
	SUSPEND,
	
	ACTIVATE;
	
	/**
	 * converts String object to ConfigAction constant
	 * 
	 * @param name - name of the action
	 * @return - ConfigAction Enum constant
	 */
	public static ConfigAction getAction(String name) {
		if(ADD.name().equals(name)) {
			return ADD;
		}
		else if (UPDATE.name().equals(name)) {
			return UPDATE;
		}
		else if (SUSPEND.name().equals(name)) {
			return SUSPEND;
		}
		else if (ACTIVATE.name().equals(name)) {
			return ACTIVATE;
		}
		
		return null;
	}
	
}