package com.isg.mw.core.model.constants;

/**
 * Transaction Message Format types
 * 
 * @author prasad_t026
 *
 */
public enum MessageFormat {

	ISO8583,
	
	AS2805,
	
	BASE24,
	
	ISG,
	
	CYBERSOURCE,
	
	MPOS,
	
	XML;
	
	/**
	 * converts String object to MessageFormat constant
	 * 
	 * @param name - name of the message format
	 * @return - MessageFormat Enum constant
	 */
	public static MessageFormat getMessageFormat(String name) {
		if(ISO8583.name().equals(name)) {
			return ISO8583;
		}
		else if (AS2805.name().equals(name)) {
			return AS2805;
		}
		else if (BASE24.name().equals(name)) {
			return BASE24;
		}
		else if (ISG.name().equals(name)) {
			return ISG;
		}
		else if (CYBERSOURCE.name().equals(name)) {
			return CYBERSOURCE;
		}
		else if (MPOS.name().equals(name)) {
			return MPOS;
		}
		else if (XML.name().equals(name)) {
			return XML;
		}
		
		return null;
	}
}