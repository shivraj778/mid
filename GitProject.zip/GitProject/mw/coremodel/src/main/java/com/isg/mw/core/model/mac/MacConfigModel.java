package com.isg.mw.core.model.mac;

import java.time.LocalDateTime;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.MessageFormat;
import com.isg.mw.core.model.constants.Status;

import lombok.Getter;
import lombok.Setter;

/**
 * Mac configuration details
 * 
 * @author shivraj3987
 *
 */

@Getter
@Setter
public class MacConfigModel {

	/**
	 * Unique id of the Mac config
	 */
	private Long id;

	/**
	 * Name of the mac config
	 */
	private String name;

	/**
	 * Message format
	 */
	private MessageFormat messageFormat;

	/**
	 * Name of the switch configuration
	 */
	private String defaultSwitch;

	/**
	 * List of preferred merchant
	 */
	private String[] merchantPreferences;

	/**
	 * List of preferred switches
	 */
	private String[] switchPreferences;

	/**
	 * Connection type
	 */
	private ConnectionType type;

	/**
	 * Socket port number
	 */
	private Integer port;

	/**
	 * Headers for web connection
	 */
	private String headersInfo;

	/**
	 * Encryption key
	 */
	private String encryptionKey;

	/**
	 * Decryption key
	 */
	private String decryptionKey;

	/**
	 * Created date
	 */
	private LocalDateTime createdDate;

	/**
	 * Updated date
	 */
	private LocalDateTime updatedDate;

	/**
	 * Status of the configuration
	 */
	private Status status;

	/**
	 * Debug to store entire packet in database
	 */
	private Boolean debug;

}
