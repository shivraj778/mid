package com.isg.mw.core.model.sw;

import java.time.LocalDateTime;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.MessageFormat;
import com.isg.mw.core.model.constants.Status;

import lombok.Getter;
import lombok.Setter;

/**
 * Switch configuration details
 * 
 * @author shivraj3987
 *
 */

@Setter
@Getter
public class SwitchConfigModel {

	/**
	 * Unique id of the config
	 */
	private Long id;

	/**
	 * Name of the config
	 */
	private String name;

	/**
	 * Message format
	 */
	private MessageFormat messageFormat;

	/**
	 * Connection type
	 */
	private ConnectionType connectionType;

	/**
	 * Socket port number
	 */
	private Integer port;

	/**
	 * Socket IP address
	 */
	private String ipAddress;

	/**
	 * URL for web connection type
	 */
	private String url;

	/**
	 * Headers for web connection type
	 */
	private String headersInfo;

	/**
	 * Encryption key
	 */
	private Byte[] encryptionKey;

	/**
	 * Decryption key
	 */
	private Byte[] decryptionKey;

	/**
	 * Created date
	 */
	private LocalDateTime createdDate;

	/**
	 * Updated date
	 */
	private LocalDateTime updatedDate;

	/**
	 * Status of the configuration
	 */
	private Status status;

}
