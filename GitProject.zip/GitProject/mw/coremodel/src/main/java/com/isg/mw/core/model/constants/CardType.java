package com.isg.mw.core.model.constants;

import java.util.regex.Pattern;

/**
 * <p>
 * Perform card validations.
 * </p>
 * 
 * <pre>
 * Amex 		: Card numbers start with a 37. 
 * Diners Club	: Card numbers begin with 300 through 305, 36 or 38. 
 * Discover 	: Card numbers begin with 6011 or 65. 
 * JCB 			: Card numbers begin with 35.
 * Maestro 		: Card numbers start with 5018, 5020, 5038, 6304, 6759, 6761 or 6763.
 * MasterCard 	: Card numbers start with the numbers 51 through 55. 
 * Union Pay	: Card numbers begin with 62.
 * Visa 		: Card numbers start with a 4.
 * Visa Master  : Card numbers start with a 4 or 5.
 * </pre>
 * 
 * @author sudarshana_t027
 */
public enum CardType {

	UNKNOWN, //
	AMERICAN_EXPRESS("^3[47][0-9]{13}$"), //
	DINERS_CLUB("^3(?:0[0-5]|[68][0-9])[0-9]{11}$"), //
	DISCOVER("^6(?:011|[45][0-9]{2})[0-9]{12}$"), //
	JCB("^(?:2131|1800|35\\d{3})\\d{11}$"), //
	MAESTRO("^(5018|5020|5038|6304|6759|6761|6763)[0-9]{8,15}$"), //
	MASTERCARD("^(?:5[1-5]|2(?!2([01]|20)|7(2[1-9]|3))[2-7])\\d{14}$"), //
	UNION_PAY("^62[0-9]{14,17}$"), //
	VISA("^4[0-9]{12}(?:[0-9]{3}){0,2}$"), //
	VISA_MASTER("^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})$"), //
	;

	private Pattern pattern;

	CardType() {
		this.pattern = null;
	}

	CardType(String pattern) {
		this.pattern = Pattern.compile(pattern);
	}

	/**
	 * Validate the card number based on bin range and find card type
	 * 
	 * @param cardNumber - Card Number
	 * @return CardType
	 */
	public static CardType detect(String cardNumber) {
		for (CardType cardType : CardType.values()) {
			if (null == cardType.pattern) {
				continue;
			}
			if ((cardNumber == null) || (cardNumber.length() < 13) || (cardNumber.length() > 19)) {
				return UNKNOWN;
			}
			if (cardType.pattern.matcher(cardNumber).matches()) {
				return cardType;
			}
		}
		return UNKNOWN;
	}

}
