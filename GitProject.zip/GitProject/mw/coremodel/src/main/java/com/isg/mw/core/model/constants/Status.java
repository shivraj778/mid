package com.isg.mw.core.model.constants;

/**
 * Config status
 * 
 * @author prasad_t026
 */
public enum Status {

	SUSPEND, 
	
	ACTIVE;

	/**
	 * converts String object to ConfigStatus constant
	 * 
	 * @param name - name of the status
	 * @return - ConfigStatus Enum constant
	 */
	public static Status getStatus(String name) {
		if (SUSPEND.name().equals(name)) {
			return SUSPEND;
		}
		else if (ACTIVE.name().equals(name)) {
			return ACTIVE;
		}
		
		return null;
	}
	
}